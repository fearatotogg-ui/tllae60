import struct, copy, json, sys, os
from pathlib import Path

class Box:
    def __init__(self, typ, payload=b'', header=8, children=None): self.type=typ; self.payload=payload; self.header=header; self.children=children

def u32(b,o): return struct.unpack_from('>I',b,o)[0]
def i32(b,o): return struct.unpack_from('>i',b,o)[0]
def u16(b,o): return struct.unpack_from('>H',b,o)[0]
def set32(b,o,v):
    if not 0 <= int(v) <= 0xffffffff: raise ValueError('MP4 field exceeds supported size')
    struct.pack_into('>I',b,o,int(v))
def set64(b,o,v): struct.pack_into('>Q',b,o,int(v))
def box(typ,payload=b''):
    typ=typ.encode('latin1') if isinstance(typ,str) else typ
    return struct.pack('>I4s',len(payload)+8,typ)+payload
CONTAINERS={'moov','trak','mdia','minf','stbl','edts'}
def parse_boxes(data, depth=0):
    if depth>=16: raise ValueError('Unexpected nested boxes')
    out=[]; p=0
    while p<len(data):
        if p+8>len(data): raise ValueError('Truncated box header')
        size=u32(data,p); typ=data[p+4:p+8].decode('latin1'); hdr=8
        if size==1:
            if p+16>len(data): raise ValueError('Truncated extended box')
            size=struct.unpack_from('>Q',data,p+8)[0]; hdr=16
        elif size==0: size=len(data)-p
        if size<hdr or p+size>len(data): raise ValueError('Invalid box extent '+typ)
        pay=bytearray(data[p+hdr:p+size])
        ch=parse_boxes(pay,depth+1) if typ in CONTAINERS else None
        out.append(Box(typ,pay,hdr,ch)); p+=size
    return out

def serialize(b):
    payload=b''.join(serialize(x) for x in b.children) if b.children is not None else b.payload
    if b.header==16: return struct.pack('>I4sQ',1,b.type.encode('latin1'),len(payload)+16)+payload
    if len(payload)+8>0xffffffff: raise ValueError('Box too large')
    return struct.pack('>I4s',len(payload)+8,b.type.encode('latin1'))+payload

def find(boxes,typ):
    a=[x for x in boxes if x.type==typ]
    if len(a)!=1: raise ValueError('Expected one '+typ+' box')
    return a[0]
def path(b,*types):
    for t in types: b=find(b.children or [],t)
    return b
def handler(track):
    p=path(track,'mdia','hdlr').payload
    if len(p)<12: raise ValueError('Missing track handler')
    return p[8:12].decode('latin1')
def sample_entry(track):
    stsd=path(track,'mdia','minf','stbl','stsd'); p=stsd.payload
    if len(p)<16 or p[0]!=0 or u32(p,4)!=1: raise ValueError('Source must have one sample description')
    entries=parse_boxes(p[8:])
    if len(entries)!=1: raise ValueError('Invalid sample description')
    return stsd,entries[0]
def parse_entry_children(entry, video=False):
    p=entry.payload; start=78 if video else (44 if u16(p,8)==1 else 28)
    if not video and (len(p)<28 or u16(p,8) not in (0,1)): raise ValueError('Unsupported AAC sample-entry version')
    if len(p)<start: raise ValueError('Truncated sample entry')
    children=[]; i=start
    while i<len(p):
        if len(p)-i<8 or all(x==0 for x in p[i:]):
            if any(p[i:]): raise ValueError('Invalid sample-entry suffix')
            break
        sz=u32(p,i); typ=p[i+4:i+8].decode('latin1'); h=8
        if sz==1:
            if i+16>len(p): raise ValueError('Truncated sample box')
            sz=struct.unpack_from('>Q',p,i+8)[0]; h=16
        elif sz==0: sz=len(p)-i
        if sz<h or i+sz>len(p): raise ValueError('Invalid sample-entry child')
        children += parse_boxes(p[i:i+sz]); i+=sz
    return start,children,p[i:]
def aac_validate(entry):
    p=entry.payload
    if entry.type!='mp4a' or len(p)<28 or u16(p,16)!=2: raise ValueError('Requires stereo AAC')
    sr=u32(p,24)/65536
    if sr not in (44100,48000): raise ValueError('Requires 44.1 or 48 kHz AAC')
    _, ch,_=parse_entry_children(entry,False)
    wave=next((x for x in ch if x.type=='wave'),None)
    esds=find(parse_boxes(wave.payload) if wave else ch,'esds')
    ep=esds.payload
    if len(ep)<=16 or ep[0]!=0: raise ValueError('Missing AAC decoder description')
    desc=parse_desc(ep[4:])
    if len(desc)!=1 or desc[0][0]!=3 or len(desc[0][1])<=3 or desc[0][1][2]!=0: raise ValueError('Unsupported AAC ES flags')
    d2=parse_desc(desc[0][1][3:]); d4=next((x for x in d2 if x[0]==4),None)
    if not d4 or len(d4[1])<=13 or d4[1][0]!=64: raise ValueError('Requires MPEG-4 AAC decoder config')
    d5=next((x for x in parse_desc(d4[1][13:]) if x[0]==5),None)
    c=3 if sr==48000 else 4
    if not d5 or len(d5[1])<2 or d5[1][0]>>3!=2 or (((d5[1][0]&7)<<1)|(d5[1][1]>>7))!=c or ((d5[1][1]>>3)&15)!=2: raise ValueError('Requires AAC-LC stereo AudioSpecificConfig')
    return int(sr)
def parse_desc(data):
    out=[]; i=0
    while i<len(data):
        typ=data[i]; i+=1; n=0; done=False
        for _ in range(4):
            if i>=len(data): break
            v=data[i]; i+=1; n=n*128+(v&127)
            if not v&128: done=True; break
        if not done or i+n>len(data): raise ValueError('Invalid AAC descriptor')
        out.append((typ,data[i:i+n])); i+=n
    return out
def enc_desc(typ,body):
    n=len(body)
    return bytes([typ,128|(n>>21),128|((n>>14)&127),128|((n>>7)&127),n&127])+body

def clock(box):
    p=box.payload; ver=p[0]
    if ver not in (0,1) or len(p)<(36 if ver else 24): raise ValueError('Unsupported media clock')
    scale=u32(p,20 if ver else 12); dur=struct.unpack_from('>Q' if ver else '>I',p,24 if ver else 16)[0]
    if scale<=0 or dur<=0 or dur==0xffffffff: raise ValueError('Invalid media duration or clock')
    return scale,dur,ver

def table_count(b,unit):
    p=b.payload
    if len(p)<8 or p[0]!=0 or len(p)!=8+u32(p,4)*unit: raise ValueError('Invalid '+b.type+' sample table')
    return u32(p,4)
def timing(track,count):
    stts=path(track,'mdia','minf','stbl','stts'); n=table_count(stts,8); samples=ticks=0
    for i in range(n):
        c=u32(stts.payload,8+i*8); d=u32(stts.payload,12+i*8)
        # ISO-BMFF permits zero-duration runs. Ignore empty runs, and allow
        # a zero delta for samples whose presentation/decode timestamps are
        # intentionally identical. These entries are retained unchanged;
        # this tool only validates the table and does not rewrite video timing.
        if c==0:
            continue
        samples+=c
        ticks+=c*d
    scale,duration,ver=clock(path(track,'mdia','mdhd'))
    if samples!=count or ticks!=duration: raise ValueError('Sample timing count or duration mismatch')
    ctts=next((x for x in path(track,'mdia','minf','stbl').children if x.type=='ctts'),None)
    if ctts:
        if len(ctts.payload)<8 or ctts.payload[0] not in (0,1) or len(ctts.payload)!=8+u32(ctts.payload,4)*8: raise ValueError('Invalid composition timing table')
        if sum(u32(ctts.payload,i) for i in range(8,len(ctts.payload),8))!=count: raise ValueError('Composition sample count mismatch')
    return {'scale':scale,'duration':duration,'version':ver,'samples':samples,'ticks':ticks}
def edit_list(track):
    ed=[x for x in track.children if x.type=='edts']
    if len(ed)>1: raise ValueError('Multiple edit lists')
    if not ed:return None
    el=find(ed[0].children,'elst'); p=el.payload; wide=p[0]==1; unit=20 if wide else 12
    if p[0] not in (0,1) or len(p)!=8+u32(p,4)*unit or u32(p,4)==0: raise ValueError('Unsupported edit list')
    rows=[]
    for i in range(u32(p,4)):
        o=8+i*unit; media=struct.unpack_from('>q' if wide else '>i',p,o+8 if wide else o+4)[0]
        rate_i=o+(16 if wide else 8)
        if media < -1 or struct.unpack_from('>h',p,rate_i)[0]!=1 or struct.unpack_from('>h',p,rate_i+2)[0]!=0: raise ValueError('Unsupported edit rate')
        dur=struct.unpack_from('>Q' if wide else '>I',p,o)[0]
        rows.append({'pos':o,'duration':dur,'mediaTime':media})
    return {'box':el,'payload':p,'wide':wide,'rows':rows}
def track_duration(track,new=None):
    tk=find(track.children,'tkhd').payload; wide=tk[0]==1; off=28 if wide else 20
    if new is not None: put_time(tk,off,new,wide)
    return struct.unpack_from('>Q' if wide else '>I',tk,off)[0]
def put_time(p,o,n,wide=False):
    if wide: struct.pack_into('>Q',p,o,n)
    else: set32(p,o,n)
def round_clock(e,t,n): return (e*n + t//2)//t
def append_table_rows(b,unit,rows):
    n=table_count(b,unit); b.payload+=b''.join(struct.pack('>'+('I'*(unit//4)),*row) for row in rows); set32(b.payload,4,n+len(rows))
def append_offsets(b,vals):
    unit=4 if b.type=='stco' else 8; n=table_count(b,unit)
    if unit==4: b.payload+=b''.join(struct.pack('>I',v) for v in vals)
    else: b.payload+=b''.join(struct.pack('>Q',v) for v in vals)
    set32(b.payload,4,n+len(vals))
def set_media_duration(mdhd, ticks):
    p=mdhd.payload; put_time(p,24 if p[0] else 16,ticks,p[0]==1)
def set_mvhd_duration(mvhd, ticks): put_time(mvhd.payload,24 if mvhd.payload[0] else 16,ticks,mvhd.payload[0]==1)
def set_track_time(track,ticks): track_duration(track,ticks)
def parse_sample_table(track,mdat):
    stbl=path(track,'mdia','minf','stbl'); stsz=find(stbl.children,'stsz').payload
    if len(stsz)<12 or stsz[0]!=0: raise ValueError('Truncated sample sizes')
    fixed=u32(stsz,4); count=u32(stsz,8)
    if count<=0 or count>1_000_000 or len(stsz)!=(12 if fixed else 12+count*4): raise ValueError('Invalid source sample count')
    offsets=[x for x in stbl.children if x.type in ('stco','co64')]
    if len(offsets)!=1: raise ValueError('Expected one chunk offset table')
    co=offsets[0]; unit=4 if co.type=='stco' else 8; chunks=table_count(co,unit)
    stsc=find(stbl.children,'stsc'); scn=table_count(stsc,12)
    if chunks<=0 or scn<=0 or u32(stsc.payload,8)!=1: raise ValueError('Invalid chunk sample mapping')
    prev=0
    for j in range(scn):
        o=8+j*12; first=u32(stsc.payload,o); per=u32(stsc.payload,o+4); desc=u32(stsc.payload,o+8)
        if first<=prev or first>chunks or per<=0 or desc!=1: raise ValueError('Invalid chunk sample rule')
        prev=first
    stts=timing(track,count)
    # chunk ranges + packet offsets
    sample=0; rule=0; ranges=[]; tail=[]; first_sample=None
    for ci in range(chunks):
        while rule+1<scn and u32(stsc.payload,8+(rule+1)*12)<=ci+1: rule+=1
        per=u32(stsc.payload,12+rule*12)
        off=u32(co.payload,8+ci*unit) if unit==4 else struct.unpack_from('>Q',co.payload,8+ci*unit)[0]
        end=off
        for _ in range(per):
            if sample>=count: raise ValueError('Chunk exceeds sample count')
            sz=fixed or u32(stsz,12+sample*4)
            if sz<=0: raise ValueError('Empty source packet')
            if sample==0:first_sample={'index':sample,'chunk':ci,'start':end,'size':sz}
            if sample>=count-4: tail.append({'index':sample,'chunk':ci,'start':end,'size':sz})
            end+=sz; sample+=1
        if off<mdat['start']+mdat['header'] or end>mdat['start']+mdat['size']: raise ValueError('Source packet points outside media')
        ranges.append((off,end))
    if sample!=count: raise ValueError('Source sample tables disagree')
    return {'count':count,'first':first_sample,'tail':tail,'ranges':ranges,'timing':stts}

def clone_entry_with_children(entry, children, prefix):
    payload=entry.payload[:prefix]+b''.join(serialize(c) for c in children)+entry.payload[len(entry.payload):] # replaced below
    return Box(entry.type,payload)
def make_audio_entries(entry,sample_rate):
    prefix,children,suffix=parse_entry_children(entry,False)
    wave=next((x for x in children if x.type=='wave'),None)
    inner=parse_boxes(wave.payload) if wave else children
    esds=find(inner,'esds'); desc=parse_desc(esds.payload[4:]); d2=parse_desc(desc[0][1][3:]); d4=next(x for x in d2 if x[0]==4); d4children=parse_desc(d4[1][13:])
    p=3 if sample_rate==48000 else 4
    asc=bytes([16|(p>>1),(p&1)<<7,4|(p>>2),(p&3)<<6,64,0,32,0])
    # Existing entry copy, reset channel/sample-rate fields as in source
    base=bytearray(entry.payload[:28]); base[8:16]=b'\0'*8; base[20:24]=b'\0'*4
    btrt=[x for x in children+(inner if wave else []) if x.type=='btrt']
    if len(btrt)>1: raise ValueError('Multiple AAC bitrate records')
    primary=Box('mp4a',bytes(base)+serialize(esds)+b''.join(serialize(x) for x in btrt))
    # rewrite DecoderSpecificInfo in AAC descriptor hierarchy
    new_d4=enc_desc(4,d4[1][:13]+b''.join(enc_desc(t,asc if t==5 else body) for t,body in d4children))
    new_d3=enc_desc(3,desc[0][1][:3]+b''.join(new_d4 if t==4 else enc_desc(t,body) for t,body in d2))
    secondary_esds=Box('esds',esds.payload[:4]+new_d3)
    secondary=Box('mp4a',bytes(base)+box('esds',secondary_esds.payload))
    return serialize(primary),serialize(secondary)

def new_udta(label):
    data=box('data',bytes.fromhex('0000000100000000')+label.encode('utf-8'))
    meta=box('meta',b'\0'*4+box('hdlr',bytes.fromhex('00000000000000006d64697200000000000000000000000000'))+box('ilst',box('©too',data)))
    return Box('udta',meta)

def transform_moov(moov_bytes, mdat, append_offset, label='TLLAE60'):
    top=parse_boxes(moov_bytes)
    if len(top)!=1 or top[0].type!='moov': raise ValueError('Missing movie header')
    moov=top[0]; mvhd=find(moov.children,'mvhd'); movie_scale=u32(mvhd.payload,20 if mvhd.payload[0] else 12)
    tracks=[x for x in moov.children if x.type=='trak']
    if not 2<=len(tracks)<=16: raise ValueError('Unsupported track count')
    videos=[x for x in tracks if handler(x)=='vide']; audios=[x for x in tracks if handler(x)=='soun']
    if len(videos)!=1 or len(audios)!=1: raise ValueError('Requires one video and one original AAC audio track')
    video,audio=videos[0],audios[0]
    vstsd,ventry=sample_entry(video); astsd,aentry=sample_entry(audio)
    # Accept both HEVC and AVC sample entries. The video samples are never
    # decoded or re-encoded by this container-level transformation.
    if ventry.type in ('hvc1','hev1','dvh1','dvhe'):
        codec='HEVC'
        config_type='hvcC'
    elif ventry.type in ('avc1','avc3'):
        codec='AVC (H.264)'
        config_type='avcC'
    else:
        raise ValueError('Unsupported video codec: this tool supports H.264/AVC and H.265/HEVC')
    vp,vc,vs=parse_entry_children(ventry,True)
    decoder_config=next((x for x in vc if x.type==config_type),None)
    min_config_size=23 if config_type=='hvcC' else 7
    if not decoder_config or len(decoder_config.payload)<min_config_size or decoder_config.payload[0]!=1:
        raise ValueError('Invalid '+codec+' decoder configuration')
    width=u16(ventry.payload,24); height=u16(ventry.payload,26)
    if not width or not height: raise ValueError('Invalid source dimensions')
    sr=aac_validate(aentry)
    ids=set(); tables={}
    for tr in tracks:
        tk=find(tr.children,'tkhd').payload; ver=tk[0]
        if ver not in (0,1) or len(tk)<(96 if ver else 84): raise ValueError('Unsupported track clock or orientation')
        tid=u32(tk,20 if ver else 12)
        if not tid or tid in ids: raise ValueError('Duplicate track identifier')
        ids.add(tid); tables[tr]=parse_sample_table(tr,mdat)
    new_id=max(ids)+1
    if new_id>=0xffffffff: raise ValueError('Track identifier limit')
    C=tables[video]; W=tables[audio]; fps=C['count']*C['timing']['scale']/C['timing']['ticks']
    if not fps>0 or W['timing']['scale']!=sr: raise ValueError('Invalid source clocks')
    tk=find(video.children,'tkhd').payload; ver=tk[0]; matoff=52 if ver else 40
    matrix=[struct.unpack_from('>i',tk,matoff+i*4)[0] for i in range(9)]
    transpose=abs(matrix[1])==65536 and abs(matrix[3])==65536
    colr=next((x for x in vc if x.type=='colr'),None); color=None
    if colr and len(colr.payload)>=10 and colr.payload[:4] in (b'nclx',b'nclc'):
        color={'primaries':u16(colr.payload,4),'transfer':u16(colr.payload,6),'matrix':u16(colr.payload,8)}
    hdr='HLG' if color and color['transfer']==18 else 'PQ' if color and color['transfer']==16 else ('Dolby Vision' if any(x.type in ('dvcC','dvvC') for x in vc) else False)
    # movie timescale chosen to exactly represent all track/edit durations
    exact=all((track_duration(tr)*1000)%movie_scale==0 and (not edit_list(tr) or all((row['duration']*1000)%movie_scale==0 for row in edit_list(tr)['rows'])) for tr in tracks)
    out_scale=1000 if exact else movie_scale
    # Normalize all track clocks to output movie clock
    for tr in tracks:
        # strip metadata, reset timestamps, normalize tkhd/mdhd/edit list durations
        tr.children=[x for x in tr.children if x.type not in ('meta','udta')]
        tk=find(tr.children,'tkhd'); md=path(tr,'mdia','mdhd')
        for b in (tk,md):
            p=b.payload; p[4:(20 if p[0] else 12)]=b'\0'*((16 if p[0] else 8))
        track_duration(tr,round_clock(track_duration(tr),movie_scale,out_scale))
        el=edit_list(tr)
        if el:
            for row in el['rows']: put_time(el['payload'],row['pos'],round_clock(row['duration'],movie_scale,out_scale),el['wide'])
        if handler(tr)=='vide':
            stsd,entry=sample_entry(tr); entry.payload=entry.payload[:42]+b'\0'*32+entry.payload[74:]
            stsd.payload=stsd.payload[:8]+serialize(entry)
    # audio sample descriptions two configs
    primary,secondary=make_audio_entries(aentry,sr)
    stbl=path(audio,'mdia','minf','stbl'); stsd=find(stbl.children,'stsd')
    stsd.payload=bytes.fromhex('0000000000000002')+primary+secondary
    stsz=find(stbl.children,'stsz'); old=stsz.payload; fixed=u32(old,4); oldcount=u32(old,8)
    new=bytearray(12+(W['count']+17)*4); new[:12]=old[:12]; set32(new,4,0); set32(new,8,W['count']+17)
    for i in range(W['count']+17): set32(new,12+i*4, fixed or u32(old,12+i*4) if i<W['count'] else len(bytes.fromhex('211004608c1c')))
    stsz.payload=bytes(new)
    stts=find(stbl.children,'stts'); count=table_count(stts,8)
    if u32(stts.payload,len(stts.payload)-4)==1024:
        set32(stts.payload,len(stts.payload)-8,u32(stts.payload,len(stts.payload)-8)+17)
    else: append_table_rows(stts,8,[(17,1024)])
    ctts=next((x for x in stbl.children if x.type=='ctts'),None)
    if ctts:
        if u32(ctts.payload,len(ctts.payload)-4)==0: set32(ctts.payload,len(ctts.payload)-8,u32(ctts.payload,len(ctts.payload)-8)+17)
        else:
            oldn=u32(ctts.payload,4); ctts.payload+=struct.pack('>II',17,0); set32(ctts.payload,4,oldn+1)
    for dep in [x for x in stbl.children if x.type in ('sdtp','stdp')]:
        unit=1 if dep.type=='sdtp' else 2
        if len(dep.payload)!=4+W['count']*unit: raise ValueError('Invalid per-sample dependency table')
        dep.payload+=bytes([32 if unit==1 else 0])*(17*unit)
    stss=next((x for x in stbl.children if x.type=='stss'),None)
    if stss: append_table_rows(stss,4,[(W['count']+i+1,) for i in range(17)])
    # audio media duration += 17 * 1024 samples
    audio_ticks=W['timing']['ticks']+17408
    set_media_duration(path(audio,'mdia','mdhd'),audio_ticks)
    # update edit list duration for original audio track
    el=edit_list(audio)
    if not el:
        # create edit list with one row
        ed=Box('edts',b'',children=[Box('elst',struct.pack('>IIQihh',0,1,round_clock(audio_ticks,sr,out_scale),0,1,0))])
        audio.children.insert(1,ed); track_duration(audio,round_clock(audio_ticks,sr,out_scale))
    else:
        valid=[r for r in el['rows'] if r['mediaTime']>=0]
        if not valid: raise ValueError('No playable audio edit')
        last=valid[-1]
        if len(el['rows'])==1:
            if audio_ticks<=last['mediaTime']: raise ValueError('Invalid audio edit duration')
            put_time(el['payload'],last['pos'],round_clock(audio_ticks-last['mediaTime'],sr,out_scale),el['wide'])
        else:
            put_time(el['payload'],last['pos'],last['duration']+round_clock(17408,sr,out_scale),el['wide'])
        total=sum(r['duration'] for r in edit_list(audio)['rows']); track_duration(audio,total)
    # Relocate chunk offsets to account for appended silence mdat and moov placement
    offsets=find(stbl.children,'co64') if any(x.type=='co64' for x in stbl.children) else find(stbl.children,'stco')
    chunks=table_count(offsets,8 if offsets.type=='co64' else 4)
    append_offsets(offsets,[append_offset+8,append_offset+8+9*6])
    append_table_rows(find(stbl.children,'stsc'),12,[(chunks+1,9,1),(chunks+2,8,2)])
    # sample group tables add 17 packets to group run
    for sbgp in [x for x in stbl.children if x.type=='sbgp']:
        p=sbgp.payload; off=12 if p[0]==0 else 16 if p[0]==1 else -1
        if off<0 or len(p)<off or len(p)!=off+u32(p,off-4)*8: raise ValueError('Invalid sample grouping')
        runs=u32(p,off-4); total=sum(u32(p,i) for i in range(off,len(p),8))
        if total!=W['count']: raise ValueError('Audio grouping count mismatch')
        sbgp.payload+=struct.pack('>II',17,0); set32(sbgp.payload,off-4,runs+1)
    # clone audio track to make silent appended track
    cloned=parse_boxes(serialize(audio))[0]
    ctk=find(cloned.children,'tkhd').payload; set32(ctk,20 if ctk[0] else 12,new_id)
    cstbl=path(cloned,'mdia','minf','stbl'); cstsd=find(cstbl.children,'stsd'); cstsd.payload=bytes.fromhex('0000000000000001')+primary
    stsc=find(cstbl.children,'stsc'); set32(stsc.payload,len(stsc.payload)-4,1)
    moov.children=[x for x in moov.children if x.type not in ('meta','udta')]
    moov.children.append(cloned); moov.children.append(new_udta(label))
    # Reset mvhd creation/modification timestamps, set movie timescale, and next track ID exactly as Mu does.
    mp=mvhd.payload
    mp[4:(20 if mp[0] else 12)]=b'\0'*((16 if mp[0] else 8))
    set32(mp,20 if mp[0] else 12,out_scale)
    set32(mp,len(mp)-4,new_id+1)
    # duration of movie set to max track duration
    maxdur=max(track_duration(x) for x in moov.children if x.type=='trak')
    set_mvhd_duration(mvhd,maxdur)
    silence=box('mdat',bytes.fromhex('211004608c1c')*17)
    return serialize(moov),silence,{'width':width,'height':height,'fps':fps,'frames':C['count'],'sourceDuration':C['timing']['ticks']/C['timing']['scale'],'duration':maxdur/out_scale,'movieTimescale':out_scale,'color':color,'hdr':hdr,'codecTag':ventry.type,'codec':codec,'sourceTracks':len(tracks),'outputTracks':len(tracks)+1,'audioPackets':W['count'],'audioSampleRate':sr,'appendedAudioPackets':17,'originalVideoPreserved':True,'encodedPicturePreserved':True}

def scan_top_level(pathname):
    size=os.path.getsize(pathname); rows=[]; pos=0
    with open(pathname,'rb') as f:
        while pos<size:
            if len(rows)>=32 or pos+8>size: raise ValueError('Invalid top-level container')
            f.seek(pos); h=f.read(16)
            if len(h)<8: raise ValueError('Truncated top-level box')
            sz=struct.unpack_from('>I',h,0)[0]; typ=h[4:8].decode('latin1'); hdr=8; extends=False
            if sz==1:
                if len(h)<16: raise ValueError('Truncated extended box')
                sz=struct.unpack_from('>Q',h,8)[0]; hdr=16
            elif sz==0:
                sz=size-pos; extends=True
            if sz<hdr or pos+sz>size: raise ValueError('Invalid media box size')
            rows.append({'type':typ,'start':pos,'size':sz,'header':hdr,'extendsToEnd':extends})
            pos+=sz
    if pos!=size: raise ValueError('Invalid top-level container extent')
    return size,rows

def process(src,dst):
    size, tops=scan_top_level(src)
    if not size or size>0xffffffff: raise ValueError('Requires a local file smaller than 4 GiB')
    types=[x['type'] for x in tops]
    if types[0]!='ftyp' or types.count('ftyp')!=1 or types.count('moov')!=1 or types.count('mdat')!=1 or any(t not in ('ftyp','wide','free','skip','mdat','moov') for t in types):
        raise ValueError('Requires a supported original MOV or MP4 top-level container')
    moov=next(x for x in tops if x['type']=='moov'); mdat=next(x for x in tops if x['type']=='mdat')
    with open(src,'rb') as f:
        f.seek(moov['start']); moov_bytes=f.read(moov['size'])
    if len(moov_bytes)!=moov['size'] or moov['size']>33554432: raise ValueError('Movie header too large or truncated')
    is_last=moov is tops[-1]
    append_offset=size if not is_last else moov['start']
    newmoov,silence,info=transform_moov(moov_bytes,mdat,append_offset)
    prefix_bytes=moov['start'] if is_last else size
    Path(dst).parent.mkdir(parents=True,exist_ok=True)
    with open(src,'rb') as inp, open(dst,'wb') as out:
        pos=0
        while pos<prefix_bytes:
            chunk=bytearray(inp.read(min(1024*1024,prefix_bytes-pos)))
            if not chunk: raise ValueError('Unexpected end of input')
            if not is_last:
                # The source worker retires the old moov payload as a free box without shifting media offsets.
                a=max(pos,moov['start']+moov['header']); b=min(pos+len(chunk),moov['start']+moov['size'])
                if a<b: chunk[a-pos:b-pos]=b'\0'*(b-a)
                # Replace the box type with "free".
                a=max(pos,moov['start']+4); b=min(pos+len(chunk),moov['start']+8)
                if a<b:
                    patch=b'free'[a-(moov['start']+4):b-(moov['start']+4)]
                    chunk[a-pos:b-pos]=patch
                # Convert any size-to-end top-level box into an explicit size.
                for row in tops:
                    if row['extendsToEnd'] and pos<=row['start']<pos+len(chunk):
                        struct.pack_into('>I',chunk,row['start']-pos,row['size'])
            out.write(chunk); pos+=len(chunk)
        out.write(silence); out.write(newmoov)
    outsize=os.path.getsize(dst)
    if outsize!=prefix_bytes+len(silence)+len(newmoov) or outsize>0xffffffff:
        try: os.remove(dst)
        except OSError: pass
        raise ValueError('Output size mismatch or exceeds 4 GiB')
    info['inputBytes']=size; info['outputBytes']=outsize
    return info

if __name__=='__main__':
    try:
        src=sys.argv[1]; dst=sys.argv[2]; print(json.dumps(process(src,dst),ensure_ascii=False,indent=2))
    except Exception as e:
        print('ERROR:',str(e)); sys.exit(2)
