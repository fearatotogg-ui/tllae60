importScripts('https://cdn.jsdelivr.net/pyodide/v0.27.7/full/pyodide.js');
let pyodidePromise=null, ffmpegPromise=null;
async function engine(){
 if(!pyodidePromise){
  self.postMessage({type:'progress',title:'تحميل محرك المعالجة',message:'تحميل محرك الحفاظ على مسار الفيديو الأصلي.'});
  pyodidePromise=loadPyodide({indexURL:'https://cdn.jsdelivr.net/pyodide/v0.27.7/full/'}).then(async py=>{
   const r=await fetch(new URL('tllae60_engine.py',self.location.href));
   if(!r.ok)throw new Error('تعذر تحميل ملف محرك TLLAE60');
   py.FS.mkdirTree('/app');py.FS.writeFile('/app/tllae60_engine.py',await r.text());
   py.runPython("import sys; sys.path.insert(0, '/app')");return py;
  });
 }
 return pyodidePromise;
}
async function originalProcess(buffer){
 const py=await engine(),input='/input_video',output='/output_video.mp4';
 py.FS.writeFile(input,new Uint8Array(buffer));
 py.globals.set('input_path',input);py.globals.set('output_path',output);
 const raw=await py.runPythonAsync(`import json\nfrom tllae60_engine import process\ninfo = process(input_path, output_path)\njson.dumps(info)`);
 const info=JSON.parse(raw),out=py.FS.readFile(output),copy=out.slice().buffer;
 py.FS.unlink(input);py.FS.unlink(output);
 return {buffer:copy,info:{...info,mode:'copy'}};
}
async function transcode(buffer,name){
 self.postMessage({type:'progress',title:'وضع التوافق الشامل',message:'الصيغة أو الترميز غير مدعوم في مسار الحفاظ الأصلي؛ نحاول تحويله إلى MP4 H.264 بمعدل 60FPS. قد يستغرق ذلك وقتًا وذاكرة أكبر.'});
 if(!ffmpegPromise){
  ffmpegPromise=new Promise((resolve,reject)=>{
   try{
    importScripts('https://unpkg.com/@ffmpeg/ffmpeg@0.11.6/dist/ffmpeg.min.js');
    if(!self.FFmpeg||!self.FFmpeg.createFFmpeg)throw new Error('تعذر تحميل محرك التحويل البديل');
    const ff=self.FFmpeg.createFFmpeg({log:false,corePath:'https://unpkg.com/@ffmpeg/core@0.11.0/dist/ffmpeg-core.js'});
    ff.load().then(()=>resolve(ff)).catch(reject);
   }catch(e){reject(e);}
  });
 }
 const ff=await ffmpegPromise;
 const ext=(String(name||'video').match(/\.([a-z0-9]{1,8})$/i)||[])[1]||'bin';
 const input='source.'+ext,output='TLLAE60_60FPS.mp4';
 try{ff.FS('writeFile',input,new Uint8Array(buffer));}catch(e){throw new Error('تعذر تجهيز الملف في ذاكرة التحويل: '+e.message);}
 self.postMessage({type:'progress',title:'تحويل الفيديو إلى 60FPS',message:'نحوّل الصورة والصوت إلى MP4 متوافق. اترك الصفحة مفتوحة ولا تغلق المتصفح.'});
 try{
  await ff.run('-i',input,'-map','0:v:0','-map','0:a:0?','-vf','fps=60','-r','60','-vsync','cfr','-c:v','libx264','-preset','veryfast','-crf','18','-pix_fmt','yuv420p','-c:a','aac','-b:a','192k','-ar','48000','-ac','2','-movflags','+faststart',output);
  const data=ff.FS('readFile',output),copy=data.slice().buffer;
  try{ff.FS('unlink',input);ff.FS('unlink',output);}catch(_){}
  return {buffer:copy,info:{mode:'transcode',fps:60,codec:'H.264',width:0,height:0}};
 }catch(e){
  try{ff.FS('unlink',input);ff.FS('unlink',output);}catch(_){}
  throw new Error('لم نستطع فك ترميز هذا الفيديو. قد يكون الترميز غير مدعوم أو الملف أكبر من ذاكرة المتصفح. التفاصيل: '+(e.message||e));
 }
}
self.onmessage=async e=>{
 if(e.data.type!=='process')return;
 try{
  let result;
  try{result=await originalProcess(e.data.buffer);}
  catch(firstError){
   self.postMessage({type:'progress',title:'تفعيل التوافق البديل',message:'مسار الحفاظ الأصلي لم يقبل هذا الملف؛ نجرب التحويل العام.'});
   result=await transcode(e.data.buffer,e.data.name);
  }
  self.postMessage({type:'done',buffer:result.buffer,info:result.info},[result.buffer]);
 }catch(err){self.postMessage({type:'error',error:String(err&&err.message||err)})}
};
